//
//  ViewController.swift
//  3
//
//  Created by Tyler Smith on 10/12/19.
//  Copyright © 2019 Tyler Smith. All rights reserved.
//
import UIKit
class ViewController: UIViewController {
    @IBOutlet weak var CementValue: UITextField!
    @IBOutlet weak var FlyAshValue: UITextField!
    @IBOutlet weak var CoarseValue: UITextField!
    @IBOutlet weak var MoistValue: UITextField!
    @IBOutlet weak var FineValue: UITextField!
    @IBOutlet weak var Moist2Value: UITextField!
    @IBOutlet weak var WaterValue: UITextField!
    @IBOutlet weak var resultLabel: UILabel!
    @IBOutlet weak var calculateButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        calculateButton.layer.borderColor = UIColor.darkGray.cgColor
    }
    @IBAction func calculate(_ sender: Any) {
        let a = Double(CementValue.text!)
        let b = Double(FlyAshValue.text!)
        let Answer = a! + b!
        resultLabel.text = "The W/C ratios is \(Answer)"
    }
}
