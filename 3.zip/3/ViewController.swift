//
//  ViewController.swift
//  3
//
//  Created by Tyler Smith on 10/12/19.
//  Copyright © 2019 Tyler Smith. All rights reserved.
//
import UIKit
class ViewController: UIViewController {
    @IBOutlet weak var valueA: UITextField!
    @IBOutlet weak var valueB: UITextField!
    @IBOutlet weak var valueC: UITextField!
    @IBOutlet weak var valueD: UITextField!
    @IBOutlet weak var valueE: UITextField!
    @IBOutlet weak var valueF: UITextField!
    @IBOutlet weak var valueG: UITextField!
    @IBOutlet weak var result: UILabel!
        override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBAction func calculate(_ sender: Any) {
        let a = Int(valueA.text!)
        let b = Int(valueB.text!)
        let Answer = a! + b!
        result.text = "The W/C ratios is \(Answer)"
    }
}
